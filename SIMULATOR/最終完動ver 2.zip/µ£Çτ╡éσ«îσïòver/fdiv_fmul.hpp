#pragma once
#include "fpu_common.hpp"
Bit32 fmul(Bit32 x1, Bit32 x2);
Bit32 fdiv(Bit32 x1, Bit32 x2);
