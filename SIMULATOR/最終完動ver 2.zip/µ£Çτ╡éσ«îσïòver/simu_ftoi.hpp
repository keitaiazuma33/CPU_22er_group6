#pragma once
#include "fpu_common.hpp"
int64_t ftoi(Bit32 x);