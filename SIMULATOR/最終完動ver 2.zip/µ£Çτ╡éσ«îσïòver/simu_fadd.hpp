#pragma once
// #include <bits/stdc++.h>
#include "fpu_common.hpp"
// using namespace std;
Bit32 fadd(Bit32 x1, Bit32 x2);