#pragma once
#include "fpu_common.hpp"
Bit32 fsqrt(Bit32 x);
