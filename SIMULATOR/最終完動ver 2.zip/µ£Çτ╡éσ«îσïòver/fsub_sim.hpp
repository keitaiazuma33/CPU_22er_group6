#pragma once
#include "fpu_common.hpp"
Bit32 fsub(Bit32 x1, Bit32 x2); //float x_1, float x_2);
